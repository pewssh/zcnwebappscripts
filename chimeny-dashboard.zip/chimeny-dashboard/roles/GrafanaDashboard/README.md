GrafanaDashboard
=========

This role setup Grafana Dashboards for monitoring of 0chain services.

Requirements
------------

It require grafana admin password which should be given as input in input.yaml